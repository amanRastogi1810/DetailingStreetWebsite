<?php 


 
class User extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		if(! $this->session->userdata('username'))
			return redirect(base_url().'crm/login');
	}

	public function index()
	{
		$this->load->view('admin/home');
	}

	public function new_booking()
	{
		$this->load->view('admin/new_booking');
	}

	public function booking_list()
	{
		$this->load->view('admin/booking_list');
	}

	public function profile()
	{
		$this->load->view('admin/profile');
	}

 
	public function new_query()
	{
		$this->load->view('admin/new_query');
	}

	public function add_query()
	{
			
			$data = array('success' => false, 'messages'=>array());

			$this->form_validation->set_rules("name","Name","trim|required");
			$this->form_validation->set_rules("email","Email","trim|required");
			$this->form_validation->set_rules("mobile","Mobile","trim|required|numeric|max_length[10]");
			$this->form_validation->set_rules("comment","Comment","trim|required");
			$this->form_validation->set_rules("car_name","Car Name","trim|required");
			$this->form_validation->set_rules("followup","Follow Up Date","trim|required");
			$this->form_validation->set_error_delimiters('<p class="text-	danger">','</p>');

				if($this->form_validation->run()) {
					$name = $this->input->post('name');
					$email = $this->input->post('email');
					$mobile = $this->input->post('mobile');
					$comment = $this->input->post('comment');
					$car_name = $this->input->post('car_name');
					$followup = $this->input->post('followup');


					$bind =  array('client_name' => $name,
						'email' => $email,
						'mobile' => $mobile,
						'car_name'=>$car_name,
						'follow_up_date	' => $followup,
						'comment' => $comment );
				//$cmd_rt = $this->my_model->insert_query($bind);



				$data = array('success' => true, 'messages'=>$bind );



				}
				else
				{
					foreach ($_POST as $key => $value)
					{
						$data['messages'][$key] = form_error($key);
					}
				}

				echo json_encode($data);
	}
	public function get_memberci()
	{
		   	$mid = $this->input->post('membership_id1');
		   	$cmd = $this->my_model->get_customer_data($mid);	


		   	$count = count($cmd);

		   		if($count > 0) {
		   			
		   		$get_bk = $this->my_model->get_booking();
				$count_bk = count($get_bk);	
				$booking_id = 'DSBK00/'.date("Y/m/d").'/'.($count_bk+1);
		   		
		   		$memberinfo = json_encode($cmd);

		   		$data = array('success' => true, 'message'=>$cmd ,'booking_id'=>$booking_id);


		   		}
		   		else
		   		{
		   			$data = array('success' => false, 'message'=>'0');
		   			
		   		}

		   		echo json_encode($data);
				/*$data = array('success' => true,'message'=>$memberinfo,'member_invalid'=>$member_invalid,'memberid'=>$mid);*/
				//echo $memberinfo;
				   

	}
	public function add_booking()
	{

			$data = array('success' => false, 'message'=>array());
			$this->form_validation->set_rules("name","Name","trim|required");
			$this->form_validation->set_rules("mobile","Mobile","trim|required|numeric|max_length[10]");
			$this->form_validation->set_rules("cnf_mobile","Confirm Mobile","trim|required|matches[mobile]");
			$this->form_validation->set_rules("address1","Address","trim|required");
			$this->form_validation->set_rules("city","City","trim|required");
			$this->form_validation->set_rules("zip_code","Zip Code","trim|required|numeric|min_length[4]|max_length[6]");
			$this->form_validation->set_error_delimiters('<p class="text-danger">','</p>');
			


			if($this->form_validation->run() ){


				$cmd = $this->my_model->get_customer();

				$get_bk = $this->my_model->get_booking();

				$count = count($cmd);

				$count_bk = count($get_bk);	

				$member_id = 'DSMB00'.($count+1);

				$booking_id = 'DSBK00/'.date("Y/m/d").'/'.($count_bk+1);
				 
				
 				

				$name = $this->input->post('name');
 				$email = $this->input->post('email');
 				$state_id = $this->input->post('state_id');
 				$address1 = $this->input->post('address1');
 				$address2 = $this->input->post('address2');
 				$mobile = $this->input->post('mobile');
 				$city = $this->input->post('city');
 				$zip_code = $this->input->post('zip_code');


 				$bind = array('customer_id' => $member_id,
 					'name' => $name,
 					 'email' => $email,
 					 'state' => $state_id,'address' => $address1.$address2,'number' => $mobile,'city' => $city,'pincode' => $zip_code,'bookingid'=>'null');

 				$insert_info = $this->my_model->insert_customer($bind);

 		$data = array('success' => true,'messages'=>$member_id,'member_id'=>$member_id,'booking_id'=>$booking_id,'insert_info'=>$insert_info);

			}
			else
			{
				foreach ($_POST as $key => $value)
				{
					$data['messages'][$key] = form_error($key);
				}
			}
			echo json_encode($data);

	}

 

	public function add_booking_bind()
	{

			$data = array('success' => false, 'messages'=>array());
 


			$this->form_validation->set_rules("car_name","Car Name","trim|required");

			$this->form_validation->set_rules("car_no","Car Number","trim|required");

			$this->form_validation->set_rules("date_time","Date Time","trim|required");

			$this->form_validation->set_error_delimiters('<p class="text-danger">','</p>'); 

			if($this->form_validation->run() ){

				$mid = $this->input->post('membership_id');
 				$car_colour = $this->input->post('car_colour');
 				$car_detail = $this->input->post('car_detail');
 				$date_time = $this->input->post('date_time');
				$picup_location = $this->input->post('picup_location');
 				$description = $this->input->post('description');
 				$price = $this->input->post('price');
 				$advance_receive = $this->input->post('advance_receive');
 				$package = $this->input->post('package');
 				$car_name = $this->input->post('car_name');
 				$car_no = $this->input->post('car_no');
 				$date_time = $this->input->post('date_time');


 	          $cmd = $this->my_model->get_customer_data($mid);	


		     	$count = count($cmd);

		   		if($count > 0) {

		   		$get_bk = $this->my_model->get_booking();
				$count_bk = count($get_bk);	
 				$booking_id = 'DSBK00/'.date("Y/m/d").'/'.($count_bk+1);
			//	$data = array('success' => true,'messages'=>$booking_id);
				
				$bind = array('booking_id' => $booking_id,
 					'vehicle' => $car_no,
 				'vehicle_name' => $car_name,
 				'vehicle_color' => $car_colour,
 				'remark_vehicle' => $car_detail,
 				'date' => $date_time,
 				'pickup' => $picup_location,
 				'remark_package' => $description,
 				'price' => $price,
 				'advance' => $advance_receive, 
 				'status' => '1',
 				'package' => $package,
 				'customer_id'=>$mid );

				  $cmd = $this->my_model->insert_booking($bind);

				  $data = array('success' => true, 'messages'=>$cmd );
		   		}
		   		else
		   		{
		   			 $data = array('success' => false, 'messages'=>'0' );
		   		}
				 

				
			}
			else
			{
				foreach ($_POST as $key => $value)
				{

					$data['messages'][$key] = form_error($key);
					
				}

			}

			echo json_encode($data);


	}

}

?>