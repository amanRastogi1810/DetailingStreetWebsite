<?php

/**
* 
*/
class crm extends CI_Controller 
{
	
	function __construct()
	{
		 parent::__construct();

		 	$this->load->model('my_model');
	}


	public function index()
	{
		$this->load->view('home');
	}

	public function forget($value='')
	{
		$this->load->view('forget');
	}



	public function login()
	{

		 if ($this->session->userdata('username') != '') {
			redirect(base_url().'user');
		}
		else
		{
			$this->load->view('login');
		}

		
	}


	public function login_validation()
	{
		 

		$data = array('success' => false, 'messages' => array());
 

		$this->form_validation->set_rules("membership_id","Membership ID","trim|required");
		$this->form_validation->set_rules("password","Password","trim|required");
		$this->form_validation->set_error_delimiters('<p class="text-danger">','</p>');
		if ($this->form_validation->run()) {
			
			$data['success'] = true;
			 
			//$data['messages'] = $_POST['membership_id'];
			
			$membership_id = $this->input->post('membership_id');
			$password = $this->input->post('password');


		

			if ($this->my_model->login_model($membership_id,$password)) {
				
				$session_data =  array('username' => $membership_id);
				$this->session->set_userdata($session_data);
				
				$data['messages'] = '1';
				//redirect(base_url().'user/home');
			
			}
			else
			{
				$data['messages'] = '0';

				// $this->session->set_flashdata('error','Invalid username and password');
			}


		}
		else
		{
			
			foreach ($_POST as $key => $value) {
				$data['messages'][$key] = form_error($key);
			}
			
		}

		echo json_encode($data);
	}


	public function check_session()
	{
		if ($this->session->userdata('username') != '') {
			redirect(base_url().'user');
		}
		else
		{
			redirect(base_url().'crm/login');
		}
	}

	public function logout()
	{
		$this->session->unset_userdata('username');
		redirect(base_url().'crm/login');
	}
}