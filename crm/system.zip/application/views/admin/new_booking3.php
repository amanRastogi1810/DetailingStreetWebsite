
<?php include('header.php'); ?>
<?php include('menu.php'); ?>
<div class="content-wrapper" style="min-height: 637px;">
   <!-- Content Header (Page header) -->
   <section class="content-header">
      <h1>
        Service Booking        
      </h1>
      <ol class="breadcrumb">
        <li>
         <a href="https://crm.onyxaa.com/admin/service-booking">
         Service Booking
          </a>        
        </li>
        <li class="active">
        New
        </li>
      </ol>  
   </section>
   <!-- Main content -->
   <section class="content">
      <div class="box box-primary">         
         <div class="box-body">           
            <form action="https://crm.onyxaa.com/admin/service-booking/new_service/ONX001878/603" class="form-horizontal" id="bookingFrm" name="bookingFrm" enctype="multipart/form-data" method="post" accept-charset="utf-8" novalidate="novalidate">
              <div class="box-body">
                <div class="col-xs-12 col-md-8">
                                      <div class="form-group">
                   <label for="Package" class="col-sm-4 control-label">Booking Type: <font class="req">*</font></label>
                   <div class="col-sm-8">
                      <select name="booking_type" id="booking_type" class="form-control valid">
                          <option value="New">New Booking</option>
                          <option value="Complaint">Complaint Booking</option>
                                                </select>
                      <input type="text" class="form-control hidden" style="margin-top: 15px; display: none;" id="complain_no" name="complain_no" placeholder="Enter complain number" value="">
                   </div>
                </div>
                  <div class="form-group">
                   <label for="date_time" class="col-sm-4 control-label">Preferred Date &amp; Time: <font class="req">*</font></label>
                   <div class="col-sm-8">
                      <input type="text" class="form-control" id="date_time" name="date_time" placeholder="Date &amp; Time">
                   </div>
                </div>
                <div class="form-group">
                   <label for="picup_location" class="col-sm-4 control-label">Pickup Location:</label>
                   <div class="col-sm-8">
                      <input type="text" class="form-control" id="picup_location" name="picup_location" placeholder="Pickup Location">
                   </div>
                </div> 
                               
                <!--  <div class="form-group " id="package_type">
                   <label for="Package" class="col-sm-4 control-label">Package: <font class="req">*</font></label>
                   <div class="col-sm-8">
                      <select name="package" id="package" class="form-control">
                          <option value="">--Select Type--</option>
                          <option value="Silver">Silver</option>
                          <option value="Gold">Gold</option>
                          <option value="Platinum">Platinum</option>
                          <option value="OwnPackage">Make your Own Package</option>
                      </select>
                   </div>
                </div> -->
                <style type="text/css">
        /*  #srvsDiv{ margin-bottom:10px;}
          #srvsDiv label,
          .coating_fog label{display: block; clear:both !important;}  
          .coating_fog label{ font-weight:normal;}
          #srvsDiv input[type="checkbox"],
          .coating_fog  input[type="checkbox"]{margin-right: 3px;}    
          #srvsDiv input[type="number"]{padding-left: 3px;  width: 50px;}     
          #srvsDiv .disabled{ display:none !important; visibility:hidden !important;}   */
        </style>                               
                <!-- <div class="form-group" id="srvsDiv" style="display:none;">     
                  <label for="date_time" class="col-sm-4 control-label">&nbsp;</label>      
                   <div class="col-sm-8"> 
                   <label class="OwnPackage disabled"><input class="" value="First Layer of Onyxaa 9H, Includes Full Detailing (refer coating process-link)" name="own_package[]" id="OwnPackage_1" type="checkbox">First Layer of Onyxaa 9H, Includes Full Detailing (refer coating process-link)</label>
                    <label class="OwnPackage disabled"><input class="" value="Front and Back Glasses" name="own_package[]" id="OwnPackage_2" type="checkbox">Front and Back Glasses</label>
                    <label class="OwnPackage disabled"><input class="" value="All Glasses" name="own_package[]" id="OwnPackage_3" type="checkbox">All Glasses</label>
                    <label class="OwnPackage disabled"><input class="" value="Wheel and Alloys" name="own_package[]" id="OwnPackage_4" type="checkbox">Wheel and Alloys</label>
                    <label class="OwnPackage disabled"><input class="" value="Extra Layer 9H" name="own_package[]" id="OwnPackage_5" type="checkbox">Extra Layer 9H &nbsp;<input id="extra_layer" name="extra_layer" class="OwnPackage disabled" min="1" max="10" step="1" value="1" type="number"></label>
                   
                    </div>                   
                </div>
                <div class="form-group " id="interior">
                   <label for="coating_fog" class="col-sm-4 control-label">Interior Coating and Anti fog: </label>
                   <div class="col-sm-8 coating_fog" style="padding-top: 8px;">
                    <label class=""><input class="coating_fog" name="coating_fog[]" id="coating_fog_1" value="Car Seats" type="checkbox">Car Seats</label>
                    <label class=""><input class="coating_fog" name="coating_fog[]" id="coating_fog_2" value="Dashboard" type="checkbox">Dashboard</label>
                    <label class=""><input class="coating_fog" name="coating_fog[]" id="coating_fog_3" value="Door Panels" type="checkbox">Door Panels</label>
                    <label class=""><input class="coating_fog" name="coating_fog[]" id="coating_fog_4" value="Interior Roof" type="checkbox">Interior Roof</label>
                    <label class=""><input class="coating_fog" name="coating_fog[]" id="coating_fog_5" value="Anti Fog" type="checkbox">Anti Fog</label>
                   </div>
                </div> -->
                <div class="form-group">
                   <label for="address1" class="col-sm-4 control-label">Remarks:</label>
                   <div class="col-sm-8">
                      <textarea class="form-control" rows="3" placeholder="Service Remarks" id="description" name="description"></textarea>
                   </div>
                </div>
                <div class="form-group" id="bookingPrice" style="">
                   <label for="price" class="col-sm-4 control-label">Price: <!--<font class="req">*</font>--></label>
                   <div class="col-sm-8">
                      <input type="text" class="form-control" id="price" name="price" placeholder="Price">
                   </div>
                </div>
                <div class="form-group" id="bookingAdvance" style="">
                   <label for="advance_receive" class="col-sm-4 control-label">Advance Received:</label>
                   <div class="col-sm-8">
                      <input type="text" class="form-control" id="advance_receive" name="advance_receive" placeholder="Advance Received">
                   </div>
                </div>
                <!-- <div class="form-group">
                   <label for="warrenty" class="col-sm-4 control-label">Warrenty Valid Upto</label>
                   <div class="col-sm-8">
                      <input type="text" class="form-control" id="warrenty" name="warrenty" placeholder="Warrenty Valid Upto">
                   </div>
                </div> 
                <div class="form-group">
                   <label for="zipcode" class="col-sm-4 control-label">Service Status:</label>
                   <div class="col-sm-8">
                      <select id="status" name="status" class="form-control">
                         <option value="O">Open </option>
                         <option value="P">Pending</option>
                         <option value="C">Completed</option>
                      </select>
                   </div>
                </div>  
                -->
              </div>
              </div>
              <div class="box-footer col-md-12">
                <div class="col-xs-12  col-md-8">
                <label class="col-sm-3 control-label"></label>
                <button class="btn btn-primary btn-next" type="submit" id="btnSubmit" style="margin-left:10px;">Submit</button>
        <button class="btn" type="reset" onclick="javascript: history.go(-1);">Cancel</button>
                </div>
             </div>
        </form>    </div>
        <!-- /.box -->      
    </div><!-- /.row -->  
    </section>
    
  </div>

  <script type="text/javascript">
      $('#radio_client input').click(function(){
     var GetValue=$('#radio_client').find(":checked").val();
     if(GetValue== "E") {
      $('#existing').show();
      $('#new_client').hide();
      }else{
        $('#existing').hide();
        $('#new_client').show();
      } 
  });

     //new_client 

$('#btnSubmit').click(function(){

    mydata = $('#bookingFrm').serialize();

      $.ajax({

            type:'post',
            data:mydata,
            url:'<?php echo base_url(); ?>user/add_booking',
            success:function(htm){
              console.log(htm);
            }

      });

});

  //   $('#bookingFrm').serialize()
  </script>
<?php include('footer.php'); ?>