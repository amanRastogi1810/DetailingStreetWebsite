<?php include('header.php'); ?>
<?php include('menu.php'); ?>
<div class="content-wrapper" style="min-height: 637px;">
   <section class="content-header">
      <h1>
        Service Booking        
      </h1>
      <ol class="breadcrumb">
        <li>
         <a href="https://crm.onyxaa.com/admin/service-booking">
         Service Booking
          </a>        
        </li>
        <li class="active">
        New
        </li>
      </ol>  
   </section>
   <!-- Main content -->
   <section class="content">
      <div class="box box-primary">  
      <br>       
         <div class="">           
            <form action="https://crm.onyxaa.com/admin/service-booking/new/ONX001878" class="form-horizontal col-md-6" id="bookingFrm" name="bookingFrm" enctype="multipart/form-data" method="post" accept-charset="utf-8" novalidate="novalidate">
              <div class="box-body">
                <div class="col-xs-12 col-md-12">
                <div class="form-group">
                  <label for="membership_id" class="col-sm-4 control-label">Membership ID: <font class="req">*</font></label>
                  <div class="col-sm-8">
                    <input type="text" class="form-control valid" id="membership_id" name="membership_id" readonly="" value="ONX001878">
                  </div>
                </div>
                <div class="form-group">
                  <label for="car_number" class="col-sm-4 control-label">Car / Bike Number: <font class="req">*</font></label>
                  <div class="col-sm-8">
                                          <input type="text" class="form-control" id="car_no" name="car_no" placeholder="Car / Bike Number">
                                        
                  </div>
                </div>
                <div class="form-group">
                  <label for="car_number" class="col-sm-4 control-label">Vehicle type: <font class="req">*</font></label>
                  <div class="col-sm-8">    
                     <div class="field-wrap" id="vehicleType">
                      <label class="radio-inline" for="vehicle_type_car">
                        <input type="radio" name="vehicle_type" class="vehicleType" id="vehicle_type_car" value="Car">Car &nbsp;&nbsp;&nbsp;
                      </label>
                      <label class="radio-inline" for="vehicle_type_bike">
                        <input type="radio" name="vehicle_type" id="vehicle_type_bike" class="vehicleType" value="Bike">Bike
                      </label>
                    </div>             
                  </div>
                </div>   
                <div class="form-group">
                  <label for="car_make" class="col-sm-4 control-label">Car / Bike make: <!--<font class="req">*</font>--></label>
                  <div class="col-sm-8">  
                    <select name="Car_brand_list" class="form-control select2 select2-hidden-accessible" id="Car_brand_list" style="width: 100%;" tabindex="-1" aria-hidden="true" onchange="return setBrandModel(this.value);" "=""><option value="">-Select-</option><option value="1">AUDI</option><option value="30">Bajaj</option><option value="2">BMW</option><option value="3">CHEVROLET</option><option value="4">DATSUN</option><option value="5">DC</option><option value="40">Ducati</option><option value="6">FIAT</option><option value="7">FORCE</option><option value="8">FORD</option><option value="38">HARLEY</option><option value="41">Harley Davidson</option><option value="31">Hero</option><option value="37">HINDUSTAN MOTOR</option><option value="9">HONDA</option><option value="10">HYUNDAI</option><option value="11">ICML</option><option value="12">ISUZU</option><option value="13">JAGUAR</option><option value="45">JEEP</option><option value="35">Kawasaki</option><option value="33">KTM</option><option value="14">LAND ROVER</option><option value="15">MAHINDRA</option><option value="16">MARUTI SUZUKI</option><option value="17">MERCEDES BENZ</option><option value="18">MINI</option><option value="19">MITSUBISHI</option><option value="20">NISSAN</option><option value="21">PORSCHE</option><option value="22">PREMIER</option><option value="23">RENAULT</option><option value="32">Royal Enfield</option><option value="24">SKODA</option><option value="42">Suzuki</option><option value="25">TATA</option><option value="26">TOYOTA</option><option value="39">Triumph</option><option value="29">TVS</option><option value="43">UM</option><option value="34">Vespa</option><option value="27">VOLKSWAGEN</option><option value="28">VOLVO</option><option value="36">YAMAHA</option></select><span class="select2 select2-container select2-container--default" dir="ltr" style="width: 100%;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="-1" aria-labelledby="select2-Car_brand_list-container"><span class="select2-selection__rendered" id="select2-Car_brand_list-container">-Select-</span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>                                 
                   <!-- <input type="text" class="form-control" id="car_make" name="car_make" placeholder="Car / Bike make"> -->
                  </div>
                </div>  
                 <div class="form-group">
                  <label for="car_model" class="col-sm-4 control-label">Car / Bike model: <!--<font class="req">*</font>--></label>
                  <div class="col-sm-8 brandModel"> 
                   <select class="form-control select2 select2-hidden-accessible" id="brand_model_list" name="brand_model_list" style="width: 100%;" tabindex="-1" aria-hidden="true">
                     <option value=""> Select </option>
                   </select><span class="select2 select2-container select2-container--default" dir="ltr" style="width: 100%;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="-1" aria-labelledby="select2-brand_model_list-container"><span class="select2-selection__rendered" id="select2-brand_model_list-container"> Select </span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>                    
                   <!-- <input type="text" class="form-control" name="car_model" id="car_model" placeholder="Car / Bike model">  -->
                  </div>
                </div>
                 <div class="form-group">
                  <label for="car_colour" class="col-sm-4 control-label">Car / Bike colour: <!--<font class="req">*</font>--></label>
                  <div class="col-sm-8">                    
                   <input type="text" class="form-control" id="car_colour" name="car_colour" placeholder="Car / Bike colour">
                  </div>
                </div>
                <div class="form-group">
                  <label for="regyear" class="col-sm-4 control-label">Registration year: <!--<font class="req">*</font>--></label>
                  <div class="col-sm-8">                    
                    <select class="form-control" id="regyear" name="regyear">
                      <option value="">--Registration year--</option>
                                            <option value="2018">2018</option>
                                         <option value="2017">2017</option>
                                         <option value="2016">2016</option>
                                         <option value="2015">2015</option>
                                         <option value="2014">2014</option>
                                         <option value="2013">2013</option>
                                         <option value="2012">2012</option>
                                         <option value="2011">2011</option>
                                         <option value="2010">2010</option>
                                         <option value="2009">2009</option>
                                         <option value="2008">2008</option>
                                         <option value="2007">2007</option>
                                         <option value="2006">2006</option>
                                         <option value="2005">2005</option>
                                         <option value="2004">2004</option>
                                         <option value="2003">2003</option>
                                         <option value="2002">2002</option>
                                         <option value="2001">2001</option>
                                         <option value="2000">2000</option>
                                         <option value="1999">1999</option>
                                         <option value="1998">1998</option>
                                         <option value="1997">1997</option>
                                         <option value="1996">1996</option>
                                         <option value="1995">1995</option>
                                         <option value="1994">1994</option>
                                         <option value="1993">1993</option>
                                     </select>
                  </div>
                </div>                   
                                       
                <div class="form-group">
                  <label for="car_detail" class="col-sm-4 control-label">Car / Bike Remarks: </label>
                  <div class="col-sm-8">                    
                    <textarea class="form-control" rows="3" placeholder="Car / Bike Remarks" id="car_detail" name="car_detail"></textarea>
                  </div>
                </div>                  
              </div>
              </div>
              <div class="box-footer col-md-12">
                <div class="col-xs-12  col-md-8">
                <label class="col-sm-3 control-label"></label>
                <button class="btn" type="reset" onclick="javascript: history.go(-1);">Cancel</button>
                <button class="btn btn-primary btn-next" id="btnSubmit" type="submit" style="margin-left:10px;">Next &gt;&gt;</button>
                <input type="hidden" id="changeModels" value="1">
                <input type="hidden" id="tempModel" value="">
                </div>
             </div>
        </form>   </div>


        <div class="box-body  ">           
            <form action="https://crm.onyxaa.com/admin/service-booking/new/ONX001878" class="form-horizontal col-md-6" id="bookingFrm" name="bookingFrm" enctype="multipart/form-data" method="post" accept-charset="utf-8" novalidate="novalidate">
              <div class="box-body">
                <div class="col-xs-12 col-md-12">
                <div class="form-group">
                  <label for="membership_id" class="col-sm-4 control-label">Membership ID: <font class="req">*</font></label>
                  <div class="col-sm-8">
                    <input type="text" class="form-control valid" id="membership_id" name="membership_id" readonly="" value="ONX001878">
                  </div>
                </div>
                <div class="form-group">
                  <label for="car_number" class="col-sm-4 control-label">Car / Bike Number: <font class="req">*</font></label>
                  <div class="col-sm-8">
                                          <input type="text" class="form-control" id="car_no" name="car_no" placeholder="Car / Bike Number">
                                        
                  </div>
                </div>
                <div class="form-group">
                  <label for="car_number" class="col-sm-4 control-label">Vehicle type: <font class="req">*</font></label>
                  <div class="col-sm-8">    
                     <div class="field-wrap" id="vehicleType">
                      <label class="radio-inline" for="vehicle_type_car">
                        <input type="radio" name="vehicle_type" class="vehicleType" id="vehicle_type_car" value="Car">Car &nbsp;&nbsp;&nbsp;
                      </label>
                      <label class="radio-inline" for="vehicle_type_bike">
                        <input type="radio" name="vehicle_type" id="vehicle_type_bike" class="vehicleType" value="Bike">Bike
                      </label>
                    </div>             
                  </div>
                </div>   
                <div class="form-group">
                  <label for="car_make" class="col-sm-4 control-label">Car / Bike make: <!--<font class="req">*</font>--></label>
                  <div class="col-sm-8">  
                    <select name="Car_brand_list" class="form-control select2 select2-hidden-accessible" id="Car_brand_list" style="width: 100%;" tabindex="-1" aria-hidden="true" onchange="return setBrandModel(this.value);" "=""><option value="">-Select-</option><option value="1">AUDI</option><option value="30">Bajaj</option><option value="2">BMW</option><option value="3">CHEVROLET</option><option value="4">DATSUN</option><option value="5">DC</option><option value="40">Ducati</option><option value="6">FIAT</option><option value="7">FORCE</option><option value="8">FORD</option><option value="38">HARLEY</option><option value="41">Harley Davidson</option><option value="31">Hero</option><option value="37">HINDUSTAN MOTOR</option><option value="9">HONDA</option><option value="10">HYUNDAI</option><option value="11">ICML</option><option value="12">ISUZU</option><option value="13">JAGUAR</option><option value="45">JEEP</option><option value="35">Kawasaki</option><option value="33">KTM</option><option value="14">LAND ROVER</option><option value="15">MAHINDRA</option><option value="16">MARUTI SUZUKI</option><option value="17">MERCEDES BENZ</option><option value="18">MINI</option><option value="19">MITSUBISHI</option><option value="20">NISSAN</option><option value="21">PORSCHE</option><option value="22">PREMIER</option><option value="23">RENAULT</option><option value="32">Royal Enfield</option><option value="24">SKODA</option><option value="42">Suzuki</option><option value="25">TATA</option><option value="26">TOYOTA</option><option value="39">Triumph</option><option value="29">TVS</option><option value="43">UM</option><option value="34">Vespa</option><option value="27">VOLKSWAGEN</option><option value="28">VOLVO</option><option value="36">YAMAHA</option></select><span class="select2 select2-container select2-container--default" dir="ltr" style="width: 100%;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="-1" aria-labelledby="select2-Car_brand_list-container"><span class="select2-selection__rendered" id="select2-Car_brand_list-container">-Select-</span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>                                 
                   <!-- <input type="text" class="form-control" id="car_make" name="car_make" placeholder="Car / Bike make"> -->
                  </div>
                </div>  
                 <div class="form-group">
                  <label for="car_model" class="col-sm-4 control-label">Car / Bike model: <!--<font class="req">*</font>--></label>
                  <div class="col-sm-8 brandModel"> 
                   <select class="form-control select2 select2-hidden-accessible" id="brand_model_list" name="brand_model_list" style="width: 100%;" tabindex="-1" aria-hidden="true">
                     <option value=""> Select </option>
                   </select><span class="select2 select2-container select2-container--default" dir="ltr" style="width: 100%;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="-1" aria-labelledby="select2-brand_model_list-container"><span class="select2-selection__rendered" id="select2-brand_model_list-container"> Select </span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>                    
                   <!-- <input type="text" class="form-control" name="car_model" id="car_model" placeholder="Car / Bike model">  -->
                  </div>
                </div>
                 <div class="form-group">
                  <label for="car_colour" class="col-sm-4 control-label">Car / Bike colour: <!--<font class="req">*</font>--></label>
                  <div class="col-sm-8">                    
                   <input type="text" class="form-control" id="car_colour" name="car_colour" placeholder="Car / Bike colour">
                  </div>
                </div>
                <div class="form-group">
                  <label for="regyear" class="col-sm-4 control-label">Registration year: <!--<font class="req">*</font>--></label>
                  <div class="col-sm-8">                    
                    <select class="form-control" id="regyear" name="regyear">
                      <option value="">--Registration year--</option>
                                            <option value="2018">2018</option>
                                         <option value="2017">2017</option>
                                         <option value="2016">2016</option>
                                         <option value="2015">2015</option>
                                         <option value="2014">2014</option>
                                         <option value="2013">2013</option>
                                         <option value="2012">2012</option>
                                         <option value="2011">2011</option>
                                         <option value="2010">2010</option>
                                         <option value="2009">2009</option>
                                         <option value="2008">2008</option>
                                         <option value="2007">2007</option>
                                         <option value="2006">2006</option>
                                         <option value="2005">2005</option>
                                         <option value="2004">2004</option>
                                         <option value="2003">2003</option>
                                         <option value="2002">2002</option>
                                         <option value="2001">2001</option>
                                         <option value="2000">2000</option>
                                         <option value="1999">1999</option>
                                         <option value="1998">1998</option>
                                         <option value="1997">1997</option>
                                         <option value="1996">1996</option>
                                         <option value="1995">1995</option>
                                         <option value="1994">1994</option>
                                         <option value="1993">1993</option>
                                     </select>
                  </div>
                </div>                   
                                       
                <div class="form-group">
                  <label for="car_detail" class="col-sm-4 control-label">Car / Bike Remarks: </label>
                  <div class="col-sm-8">                    
                    <textarea class="form-control" rows="3" placeholder="Car / Bike Remarks" id="car_detail" name="car_detail"></textarea>
                  </div>
                </div>                  
              </div>
              </div>
              <div class="box-footer col-md-12">
                <div class="col-xs-12  col-md-8">
                <label class="col-sm-3 control-label"></label>
                <button class="btn" type="reset" onclick="javascript: history.go(-1);">Cancel</button>
                <button class="btn btn-primary btn-next" id="btnSubmit" type="submit" style="margin-left:10px;">Next &gt;&gt;</button>
                <input type="hidden" id="changeModels" value="1">
                <input type="hidden" id="tempModel" value="">
                </div>
             </div>
        </form>   </div>
        <!-- /.box -->      
    </div><!-- /.row -->  
    </section>
    
  </div>

  <script type="text/javascript">
      $('#radio_client input').click(function(){
     var GetValue=$('#radio_client').find(":checked").val();
     if(GetValue== "E") {
      $('#existing').show();
      $('#new_client').hide();
      }else{
        $('#existing').hide();
        $('#new_client').show();
      } 
  });

     //new_client 

$('#btnSubmit').click(function(){

    mydata = $('#bookingFrm').serialize();

      $.ajax({

            type:'post',
            data:mydata,
            url:'<?php echo base_url(); ?>user/add_booking',
            success:function(htm){
              console.log(htm);
            }

      });

});

  //   $('#bookingFrm').serialize()
  </script>
<?php include('footer.php'); ?>