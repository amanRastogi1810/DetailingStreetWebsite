
<?php include('header.php'); ?>
<?php include('menu.php'); ?>

<div class="content-wrapper" style="min-height: 542px;">
   <!-- Content Header (Page header) -->
   <section class="content-header">
      <h1>
         Service Booking List
         <small> <a href="http://localhost/mayank/admin/service-booking/new" class="btn btn-primary">Add a new</a> </small>
      </h1>
      <ol class="breadcrumb">
         <li class="active">
            Service Booking List
         </li>
      </ol>
   </section>
   <!-- Main content -->
   <section class="content">
      <div class="row">
         <div class="col-xs-12">
            <div class="box box-primary">
               <!-- /.box-header -->
               <div class="box-body">
                                
                  <div id="list1_wrapper" class="dataTables_wrapper form-inline dt-bootstrap">
                     <div class="row">
                            
                        <div class="col-sm-9">
                           <div class="form-group">
                              <form action="http://localhost/mayank/admin/service-booking" class="form-inline reset-margin" id="myform" method="get" accept-charset="utf-8" novalidate="novalidate">
<label for="filterby">Filter by :&nbsp;&nbsp;&nbsp;</label><select name="filterby" id="filterby" class="form-control">
<option value="" selected="selected">- Select -</option>
<option value="membership_id">Membership ID</option>
<option value="car_no">Car / Bike Number</option>
<option value="booking_id">Booking ID</option>
<option value="mobile_no">Mobile no.</option>
</select>
<label for="search_string">Search :&nbsp;</label><input type="text" name="search_string" value="" id="search_string" class="form-control">
<label for="order">Order by:&nbsp;</label><select name="order_type" class="span1 form-control">
<option value="Asc">Asc</option>
<option value="Desc" selected="selected">Desc</option>
</select>
<input type="hidden" name="workshop" value=""><label for="srv_status">Status :&nbsp;&nbsp;</label><select name="srv_status" class="span1 form-control">
<option value="A">All</option>
<option value="O" selected="selected">Open</option>
<option value="C">Completed</option>
<option value="X">Cancelled</option>
</select>
&nbsp;&nbsp;&nbsp;<input type="submit" name="btnSearch" value="Go" class="btn btn-primary">
</form>                           </div>
                           <br><br>
                        </div>
                                             </div>
                     <div class="row">
                        <div class="col-sm-12">
                           <table id="list1" class="table table-bordered table-striped dataTable" role="grid" aria-describedby="list1_info">
                              <!--table-hover--> 
                              <thead>
                                 <tr role="row">
                                    <th class="header">#</th>
                                    <th class="yellow header headerSortDown" nowrap="nowrap" width="1%">Booking No</th>
                                    <th class="yellow header headerSortDown" nowrap="nowrap" width="1%">Type of Booking</th>
                                    <th class="yellow header headerSortDown">Car / Bike Number</th>
                                    <th class="yellow header headerSortDown">Service Remarks</th>
                                    <th class="yellow header headerSortDown">Preferred Date &amp; Time</th>
                                    <th class="red header">Actions</th>
                                 </tr>
                              </thead>
                              <tbody>                      
                                 <tr><td>1</td><td><a href="http://localhost/mayank/admin/service-booking/view/2259 " title="Mayank Bhatnagar, 09871753634">BRN002259</a></td><td>New</td><td>kjhjk</td><td></td><td><strong>Date:</strong> 26th Apr 2018<br><strong>Time:</strong> 09:16 PM</td><td class="crud-actions"><a href="http://localhost/mayank/admin/service-booking/view/2259 " title="View"><i class="fa fa-eye"></i></a><a href="http://localhost/mayank/admin/service-booking/update/2259" title="Edit"><i class="fa fa-edit"></i></a><a href="http://localhost/mayank/admin/service-booking/jobcard/2259 " title="Job Card">Generate Job Card</a></td></tr>      
                              </tbody>
                           </table>
                           <div class="pagination"></div>                        </div>
                     </div>
                     <p>&nbsp;</p>
                  </div>
               </div>
               <!-- /.box-body -->
            </div>
            <!-- /.box -->
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->  
   </section>
   <!-- /.content -->
</div>
<?php include('footer.php'); ?>