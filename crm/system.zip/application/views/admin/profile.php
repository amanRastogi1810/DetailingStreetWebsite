
<?php include('header.php'); ?>
<?php include('menu.php'); ?>


<div class="content-wrapper" style="min-height: 673px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>Profile Detail</h1>
      <ol class="breadcrumb">
        <li><a href="https://crm.onyxaa.com/dashboard">Profile</a></li>
        <li class="active">Profile Detail</li>
      </ol>       
    </section>
<!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12 col-md-12">
        <div class="box box-primary">
                     <div class="box-body">
           <div class="col-xs-12 col-md-8">
      <table id="list1" class="table table-bordered table-striped dataTable" role="grid" aria-describedby="list1_info">
            <tbody><tr><td><strong>Name:</strong></td><td>RADIANT DETAILERS</td></tr>
            <tr><td><strong>Email:</strong></td><td>radiant@onyxaa.com</td></tr>
                       <tr><td><strong>Address:</strong></td><td>C-58, MANSAROVER GARDEN</td></tr>
                                 <tr><td><strong>Phone:</strong></td><td>9643431699</td></tr>
          </tbody></table>
      </div>
          </div>
       </div>
        <!-- /.box --> 
      </div>
      <!-- /.col --> 
    </div>
    <!-- /.row --> 
  </section>
  <!-- /.content --> 
</div>

 
<?php include('footer.php'); ?>