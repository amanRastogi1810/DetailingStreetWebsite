
  <aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      <!-- Sidebar user panel (optional) -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="https://crm.onyxaa.com/assets/dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>Admin</p>
          <!-- Status -->
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>

      <!-- search form (Optional) -->
<!--       <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form> -->
      <!-- /.search form -->

      <!-- Sidebar Menu --> 
      <ul class="sidebar-menu">    
        <!--<li class="header">HEADER</li>-->
        <!-- Optionally, you can add icons to the links -->
        
					<li class="treeview">
          				<a href="#">
							<i class="fa fa-link"></i> <span>Profile</span>
							<span class="pull-right-container">
							  <i class="fa fa-angle-left pull-right"></i>
							</span>
          				</a><ul class="treeview-menu"><li class =""><a href="<?php echo base_url(); ?>user/profile"><i class="fa fa-circle-o"></i>My Profile</a></li><!-- <li class =""><a href="<?php echo base_url(); ?>admin/profile/update"><i class="fa fa-circle-o"></i>Manage Profile</a></li><li class =""><a href="<?php echo base_url(); ?>admin/profile/change_password"><i class="fa fa-circle-o"></i>Change Password</a></li> --></ul></li>
					<li class="treeview">
          				<a href="#">
							<i class="fa fa-link"></i> <span>Manage Clients</span>
							<span class="pull-right-container">
							  <i class="fa fa-angle-left pull-right"></i>
							</span>
          				</a><ul class="treeview-menu"><li class =""><a href="<?php echo base_url(); ?>admin/clients"><i class="fa fa-circle-o"></i>Manage Clients</a></li></ul></li>
					<li class="treeview">
          				<a href="#">  
							<i class="fa fa-link"></i> <span>Service Booking </span>
							<span class="pull-right-container">
							  <i class="fa fa-angle-left pull-right"></i>
							</span>
          				</a><ul class="treeview-menu"><li class =""><a href="<?php echo base_url(); ?>user/new_booking"><i class="fa fa-circle-o"></i>Booking</a></li><li class =""><a href="<?php echo base_url(); ?>user/booking_list"><i class="fa fa-circle-o"></i>List Booking</a></li></ul></li>
					<!-- <li class="treeview">
          				<a href="#">
							<i class="fa fa-link"></i> <span>Complaints</span>
							<span class="pull-right-container">
							  <i class="fa fa-angle-left pull-right"></i>
							</span>
          				</a><ul class="treeview-menu"><li class =""><a href="<?php echo base_url(); ?>admin/complaints/add"><i class="fa fa-circle-o"></i>Add New</a></li><li class =""><a href="<?php echo base_url(); ?>admin/complaints"><i class="fa fa-circle-o"></i>List Complaints</a></li></ul></li> -->
<!-- 					<li class="treeview">
          				<a href="#">
							<i class="fa fa-link"></i> <span>Manage Invoice</span>
							<span class="pull-right-container">
							  <i class="fa fa-angle-left pull-right"></i>
							</span>
          				</a><ul class="treeview-menu"><li class =""><a href="<?php echo base_url(); ?>admin/service-invoice"><i class="fa fa-circle-o"></i>Invoice List</a></li></ul></li> -->
<!-- 					<li class="treeview">
          				<a href="#">
							<i class="fa fa-link"></i> <span>Reports</span>
							<span class="pull-right-container">
							  <i class="fa fa-angle-left pull-right"></i>
							</span>
          				</a><ul class="treeview-menu"><li class =""><a href="<?php echo base_url(); ?>admin/reports"><i class="fa fa-circle-o"></i>List Reports</a></li><li class =""><a href="<?php echo base_url(); ?>admin/reports/inspections"><i class="fa fa-circle-o"></i>Inspection List</a></li></ul></li> -->
					<li class="treeview">
          				<a href="#">
							<i class="fa fa-link"></i> <span>Manage Query</span>
							<span class="pull-right-container">
							  <i class="fa fa-angle-left pull-right"></i>
							</span>
          				</a><ul class="treeview-menu"><li class =""><a href="<?php echo base_url(); ?>user/new_query"><i class="fa fa-circle-o"></i>Add Query</a></li><li class =""><a href="<?php echo base_url(); ?>admin/query"><i class="fa fa-circle-o"></i>List Query</a></li><li class =""><a href="<?php echo base_url(); ?>admin/query/complaint"><i class="fa fa-circle-o"></i>List Query Complaint</a></li></ul></li>
					<li class="treeview">
          				<a href="#">
							<i class="fa fa-link"></i> <span>Follow up</span>
							<span class="pull-right-container">
							  <i class="fa fa-angle-left pull-right"></i>
							</span>
          				</a><ul class="treeview-menu"><li class =""><a href="<?php echo base_url(); ?>admin/followup"><i class="fa fa-circle-o"></i>List Follow up</a></li></ul></li>
<!-- 					<li class="treeview">
          				<a href="#">
							<i class="fa fa-link"></i> <span>Pricing</span>
							<span class="pull-right-container">
							  <i class="fa fa-angle-left pull-right"></i>
							</span>
          				</a><ul class="treeview-menu"><li class =""><a href="<?php echo base_url(); ?>admin/pricing"><i class="fa fa-circle-o"></i>View Pricing</a></li></ul></li> -->
<!-- 					<li class="treeview">
          				<a href="#">
							<i class="fa fa-link"></i> <span>Payment</span>
							<span class="pull-right-container">
							  <i class="fa fa-angle-left pull-right"></i>
							</span>
          				</a><ul class="treeview-menu"><li class =""><a href="<?php echo base_url(); ?>admin/payment/request_money"><i class="fa fa-circle-o"></i>Request Money</a></li><li class =""><a href="<?php echo base_url(); ?>admin/payment/status"><i class="fa fa-circle-o"></i>Status</a></li></ul></li>  -->
                      
                     
      </ul>
      <!-- /.sidebar-menu -->
	       </section>
    <!-- /.sidebar -->
  </aside>