<?php 
$this->load->model('my_model');
$invoice = $this->my_model->get_data('invoice'); 
include('header.php');
include('menu.php'); ?>
<style type="text/css">
  address span{
    color: red;
  }
</style>
<div class="content-wrapper" style="min-height: 542px;">
   <!-- Content Header (Page header) -->
   <section class="content-header">
      <h1>
         Report 
      </h1>
      <ol class="breadcrumb">
         <li class="active">
            User Reporting
         </li>
      </ol>

   </section>

   <!-- Main content -->

   <section class="content">

      <div class="row">

         <div class="col-xs-12">

            <div class="box box-primary">

               <!-- /.box-header -->

               <div class="box-body">

                                

                  <div id="list1_wrapper" class="dataTables_wrapper form-inline dt-bootstrap">
                     <div class="row">
                        <div class="col-sm-9">
                           <div class="form-group">
                            </div>
                           <br> <br>
                        </div>
                      </div>
                     <div class="row">
<div class="col-sm-12">
  <div class="col-sm-6">
                    <select class="form-control valid" name="search_col" id="search_col">
                        <option value="customer_id">Customer ID </option>
                        <option value="vehicle">Car Number </option>
                        <option value="number">Mobile </option>
                    </select>

      <input type="text" class="form-control" name="search_txt" id="search_txt" placeholder="Enter Selected Option">
      
                    <button class="btn btn-primary btn-next" type="button" id="btn_searchreport" style="margin-left:10px;">Search </button>
                    <br>
                    <br>
                  </div>

                  <table id="" class="table table-bordered table-striped dataTable" role="grid" aria-describedby="list1_info" style="overflow: auto;" >
                              <thead>
                              <tr role="row">
	                              <th class="header">#</th>
                                 <th class="yellow header headerSortDown">Name</th>
                                  <th class="yellow header headerSortDown">Number</th>
                                 <th class="yellow header headerSortDown">Email</th>
                                 <th class="yellow header headerSortDown">Branch</th>
	                             <th class="yellow header headerSortDown" nowrap="nowrap" width="1%">BookingID</th>
	                             <th class="yellow header headerSortDown" nowrap="nowrap" width="">CustomerID</th>
	                              <th class="red header">Actions</th>
                              </tr>
                              </thead>
                              <tbody id="print">
                                
                              </tbody>
                           </table>
                      <div class="pagination"></div>
                </div>

                     </div>

                     <p>&nbsp;</p>

                  </div>

               </div>

               <!-- /.box-body -->

            </div>

            <!-- /.box -->

         </div>

         <!-- /.col -->

      </div>

      <!-- /.row -->  

   </section>

   <!-- /.content -->


<!-- Modal -->
  <div class="modal fade " id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Customer Details </h4>
        </div>
        <div class="modal-body">
         <section class="invoice">
      <!-- title row -->
 
      <!-- info row -->
      <div class="row invoice-info">
        
          <div class="col-md-6 invoice-col">
          <h3>Customer Info </h3>
           <hr>
              <address>
             
            Phone: <span id="cphone"></span><br>
            Email: <span id="cemail"></span><br>

            Address: <span class="cls_address"></span><br>
            City: <span class="cls_city"></span><br>
            Pincode: <span class="cls_pin"></span>
          </address>
           
        </div>
        <div class="col-md-6 invoice-col">
         <h3> Booking Info</h3>
           <hr>
            
        </div>
        <div class="col-md-12 invoice-col">
         <h3> Customer Invoice</h3>
           <hr>
           
        </div>
 
      </div> 
 
      <div class="row" id="jdata">
        
      </div>
      <!-- /.row -->

      <!-- this row will not appear when printing -->
      <div class="row no-print">
        
      </div>
    </section>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>


    


</div>
<script type="text/javascript">
 
   $(document).on('click','#btn_searchreport',function(){

   		search_col =	$('#search_col').val();
   		search_txt =	$('#search_txt').val();

  /*    if (search_txt == '') {
        alert('please enter uniqe id number .')
      }
      else
      {*/
                $.ajax({
                  type:'post',
                  url:'<?php echo base_url();?>user/report',
                  data:{'search_col':search_col,'search_txt':search_txt},
                  dataType:'text',
                  success:function(htm){
                    console.log(htm);
                    $('#print').html(htm);
                  }
            });
     // }



   });


   $(document).on('click','.cls_bk_details',function(){

           cid = $(this).attr('id');
           sno = $(this).attr('data-sno');
           mdata = 'cid='+escape(cid)+'&sno='+escape(sno);
            
            $.ajax({
                 type:'post',
                 url:'<?php echo base_url(); ?>user/get_client_by_bk',
                 data:mdata,
                 dataType:'json',
                  
                 success:function(htm){
                     console.log(htm);

                      $('#cid').text(htm[0].customer_id);
                      $('#cname').text(htm[0].name);
                      $('#cphone').text(htm[0].number);
                      $('#cemail').text(htm[0].email);

                      $('#bid').text(htm[0].booking_id);

                      $('.car_name').text(htm[0].vehicle_name);
                      $('.car_number').text(htm[0].vehicle);
                      $('.car_color').text(htm[0].vehicle_color);

                      $('.car_remark').text(htm[0].remark_vehicle);
                      $('.pik_location').text(htm[0].pickup);
                      $('.remark').text(htm[0].remark_package);

                      /*$('.cls_advance').text(htm[0].advance);*/


                      $('.clsprice').text(htm[0].price);
                      $('.cls_received').text(htm[0].advance);
                      $('.cls_package').text(htm[0].package);
                      $('.date_pre').text(htm[0].date);

  

                            $('.cls_address').text(htm[0].address);
                      $('.cls_city').text(htm[0].city);
                      $('.cls_pin').text(htm[0].pincode);
                       
                       

                 } 

            });
   });

   // 

   

  // cls_bk_edit

   

   
   
</script>
<?php include('footer.php'); ?>