<?php

 

class My_Model extends CI_Model
{

	

	function __construct()

	{

		parent::__construct();



		$this->load->database();



	}


	public function get_data($table)
	{

		$cmd = $this->db->select('*')->get($table)->result();
		return $cmd;

	}

	public function get_today_follow($table,$value)
	{
		$cmd = $this->db->select('*')->from($table)->where('follow_up_date',$value)->where('status','1')->get();
		return $cmd->result();
	}

    public function get_miss_follow($table,$value)
	{
		$cmd = $this->db->select('*')->from($table)->where('follow_up_date <=',$value)->where('status','1')->get();
		return $cmd->result();
	}

	public function get_table_by_column($table,$column,$id)
	{
		$cmd= $this->db->select('*')->from($table)->where($column, $id)->get();
		return $cmd->result();
	}


	public function get_client($cid,$sno)
	{
	


		 $query = $this->db->select('*')
		 					->from('booking')
		 					->join('customer','booking.customer_id = customer.customer_id')
		 					
		 					->where('booking.sno',$sno)
		 					->get();  	
         return $query->result();
	}



	public function delete_fun($table,$bind)
	{
		
		$cmd = $this->db->delete($table,$bind);

		return $cmd;
	}

	public function login_model($membership_id,$password)

	{



		$query = $this->db->select('*')->where(['username'=>$membership_id,'password'=>$password])->get('admin_login');

	/*	$this->db->where('username',$membership_id);

		$this->db->where('password',$password);*/



	//	$query = $this->get('admin_login')->result();



		/*print_r($query);*/

		if ($query->num_rows() > 0) {

			return true;

		}

		else

		{

			return false;

		}

	}



	public function get_customer_data($mid)

	{

		$cmd = $this->db->select('*')->where('customer_id',$mid)->get('customer')->result();



		return $cmd;

	}



	public function get_customer()

	{

		$cmd = $this->db->select('*')->get('customer')->result();



		return $cmd;

	}



	public function get_booking()

	{

		$cmd = $this->db->select('*')->get('booking')->result();



		return $cmd;

	}



	public function insert_customer($bind)

	{

		$cmd = $this->db->insert("customer",$bind);

		return $cmd;

	}



	public function insert_booking($bind)

	{

		$cmd = $this->db->insert("booking",$bind);

		return $cmd;

	}



	public function insert_query($bind)
	{

		$cmd = $this->db->insert("query",$bind);

		return $cmd;

	}

	public function update_customer($table,$column,$bind,$id)
	{
		 
		//echo '$this->db->where($column, $id)->update($table, $bind)';
		$cmd= $this->db->where($column, $id)->update($table, $bind);
		 return $cmd;
	}




}



?>