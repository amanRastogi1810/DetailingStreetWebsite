<?php 
 

class User extends CI_Controller

{

	

	function __construct()

	{

		parent::__construct();

		$this->load->model('my_model');
		  $this->load->library('email'); 

		if(! $this->session->userdata('username'))

			return redirect(base_url().'crm/login');

	}



	public function index()

	{

		$this->load->view('admin/home');

	}

	public function home()

	{

		$this->load->view('admin/home');

	}
	public function dashboard()

	{

		$this->load->view('admin/home');

	}

	public function pricing()

	{

		$this->load->view('admin/pricing');

	}



	public function new_booking()

	{

		$this->load->view('admin/new_booking');

	}





	public function booking_list()
	{
		 $data = array();

		 $data['booking'] = $this->my_model->get_data('booking');
		  
		$this->load->view('admin/booking_list',['info'=>$data]);

	}

	public function invoice()
	{
		 $data = array();

		 $data['booking'] = $this->my_model->get_data('booking');
		  
		$this->load->view('admin/invoice',['info'=>$data]);
		
	}

	public function query_list()
	{
		 $data = array();

		 $data['query'] = $this->my_model->get_data('query');
		  
		$this->load->view('admin/query_list',['info'=>$data]);

	}



	public function profile()
	{

		$this->load->view('admin/profile');

	}
 

	public function new_query()
	{

		$this->load->view('admin/new_query');

	}

	public function get_booking_byid()
	{

		 $qid = $_POST['bid'];
		 $table = 'booking';
		 $column = 'booking_id';

		 $cmd = $this->my_model->get_table_by_column($table,$column,$qid);
		 
		 
		 echo json_encode($cmd);

	}

	public function get_query_byid()
	{

		 $qid = $_POST['qid'];
		 $table = 'query';
		 $column = 'sno';

		 $cmd = $this->my_model->get_table_by_column($table,$column,$qid);
		 echo json_encode($cmd);

	}

	public function get_query_details()
	{

		 $qid = $_POST['sno'];
		 $table = 'query';
		 $column = 'sno';
		
		 $cmd = $this->my_model->get_table_by_column($table,$column,$qid);
		 echo json_encode($cmd);

	}

	public function followup()
	{
		$data = array();
		$table = 'query';
		$value = date('Y-m-d');
		$data['today'] = $this->my_model->get_today_follow($table,$value);
		$data['missed'] = $this->my_model->get_miss_follow($table,$value);
		$data['all'] = $this->my_model->get_data($table);
		$this->load->view('admin/followup',['info'=>$data]);
	}

	public function get_client_by_bk()
	{ 

		 $cid = $this->input->post('cid');
		 $sno = $this->input->post('sno');
		 $cmd = $this->my_model->get_client($cid,$sno);
		 echo json_encode($cmd);
	}



	public function add_query()
	{
			$data = array('success' => false, 'messages'=>array());
			$this->form_validation->set_rules("name","Name","trim|required|alpha_numeric_spaces");
			$this->form_validation->set_rules("email","Email","trim|required|valid_email");
			$this->form_validation->set_rules("mobile","Mobile","trim|required|numeric|max_length[10]");
			$this->form_validation->set_rules("comment","Comment","trim|required|alpha_numeric_spaces");
			$this->form_validation->set_rules("car_name","Car Name","trim|required|alpha_numeric_spaces");
			$this->form_validation->set_rules("followup","Follow Up Date","trim|required");
			$this->form_validation->set_error_delimiters('<p class="text-danger" style="color:red;">','</p>');
				if($this->form_validation->run()) {
					$name = $this->input->post('name');

					$email = $this->input->post('email');

					$mobile = $this->input->post('mobile');

					$comment = $this->input->post('comment');

					$car_name = $this->input->post('car_name');

					$followup = $this->input->post('followup');


					$query_date = date('Y-m-d h:i:s A');



					$bind =  array('client_name' => $name,

						'email' => $email,

						'mobile' => $mobile,

						'car_name'=>$car_name,


						'follow_up_date	' => $followup,

						'comment' => 'Date :'.$query_date.'&Comment :'.$comment.';',
						 'status' => '1',
						 'query_date' => $query_date		);

				$cmd_rt = $this->my_model->insert_query($bind);







				$data = array('success' => true, 'messages'=>$cmd_rt		 );







				}

				else

				{

					foreach ($_POST as $key => $value)

					{

						$data['messages'][$key] = form_error($key);

					}

				}



				echo json_encode($data);

	}

	public function get_memberci()

	{

		   	$mid = $this->input->post('membership_id1');
		   	$cmd = $this->my_model->get_customer_data($mid);	

		   	$count = count($cmd);
		   		if($count > 0) {

		   		$get_bk = $this->my_model->get_booking();

				$count_bk = count($get_bk);	

				$booking_id = 'DSBK00'.($count_bk+1);

		   		

		   		$memberinfo = json_encode($cmd);



		   		$data = array('success' => true, 'message'=>$cmd ,'booking_id'=>$booking_id);





		   		}

		   		else

		   		{

		   			$data = array('success' => false, 'message'=>'0');

		   			

		   		}



		   		echo json_encode($data);

 


	}

	public function del_fullowup()
	{
		 $sno = $this->input->post('sno');


		 //

		 $bind = array('sno' => $sno);
		 $table = 'query';
		 $b = $this->my_model->delete_fun($table,$bind);
		 return $b;

	}

	public function del_fullowup_booking()
	{
		 $sno = $this->input->post('sno');


		 //

		 $bind = array('sno' => $sno);
		 $table = 'booking';
		 $b = $this->my_model->delete_fun($table,$bind);
		 return $b;

	}

	public function update_query()
	{
			$data = array('success' => false, 'messages'=>array());

			
			
	$this->form_validation->set_rules("id_query","Refresh Page And Try Again","trim|required");
	$this->form_validation->set_rules("sel_status","Name","trim|required");
	$this->form_validation->set_rules("comment","Comment without any alpha numeric characters","trim|alpha_numeric_spaces|required|min_length[10]");
			$this->form_validation->set_rules("followup_date","Date","trim|required");
			$this->form_validation->set_error_delimiters('<p class="text-danger">','</p>');

				if($this->form_validation->run() ){
				$sno = $this->input->post('id_query');
 				$status = $this->input->post('sel_status');
 				$comment = $this->input->post('comment');
 				$follow_date = $this->input->post('followup_date');

 				$table = 'query';
 				$column = 'sno';

 				$data_query = $this->my_model->get_table_by_column($table,$column,$sno);

 				 $last_coment = $data_query[0]->comment;

 				$date=date_create($follow_date);
				 $followon = date_format($date,"Y-m-d");
				 $full_coment = $last_coment.'Date:'.$follow_date.'&Comment:'.$comment.'.;';
 				 
 				$bind = array('comment' => $full_coment,
 					 			'follow_up_date' => $followon,
								'status' => $status );
 				$insert_info = $this->my_model->update_customer($table,$column,$bind,$sno);
 				$data = array('success' => true,'messages'=>'updated','insert_info'=>$last_coment);
			}
			else
			{

				foreach ($_POST as $key => $value)
				{
					$data['messages'][$key] = form_error($key);
				}
			}
			echo json_encode($data);		
	}

	public function update_query_new()
	{
			$data = array('success' => false, 'messages'=>array());

			
			
	$this->form_validation->set_rules("query_sno","Refresh Page And Try Again","trim|required");
	$this->form_validation->set_rules("query_name","Name","trim|required");
	$this->form_validation->set_rules("query_email","Email","trim|required|valid_email");
	$this->form_validation->set_rules("query_phone","Mobile","trim|required|numeric|max_length[10]");

	$this->form_validation->set_rules("query_follow","Date","trim|required");

	$this->form_validation->set_rules("query_car","Date","trim|required");

	 
			$this->form_validation->set_error_delimiters('<p class="text-danger">','</p>');

				if($this->form_validation->run() ){
				$sno = $this->input->post('query_sno');
 				$query_name = $this->input->post('query_name');
 				
 				$query_email = $this->input->post('query_email');
 				$query_phone = $this->input->post('query_phone');
 				$query_follow = $this->input->post('query_follow');
 				$query_car = $this->input->post('query_car');

 				$table = 'query';
 				$column = 'sno'; 
 				 
 				$bind = array(  'client_name' => $query_name,
 					 			'email' => $query_email,
								'car_name' => $query_car,
								'follow_up_date' => $query_follow,
								'mobile' => $query_phone );

 				$insert_info = $this->my_model->update_customer($table,$column,$bind,$sno);
 				$data = array('success' => true,'messages'=>'updated');
			}
			else
			{

				foreach ($_POST as $key => $value)
				{
					$data['messages'][$key] = form_error($key);
				}
			}
			echo json_encode($data);		
	}


	public function update_client()
	{
			$data = array('success' => false, 'messages'=>array());
			$this->form_validation->set_rules("ecname","Name","trim|required");
			$this->form_validation->set_rules("ecnumber","Mobile","trim|required|numeric|max_length[10]");
			$this->form_validation->set_rules("ecemail","Email","trim|required|valid_email");
			$this->form_validation->set_rules("ecaddress","Address","trim|required");

			$this->form_validation->set_rules("eprice","Price","trim|required");
			$this->form_validation->set_rules("epackage","Package","trim|required");
			$this->form_validation->set_rules("epredate","Date","trim|required");

			$this->form_validation->set_rules("epiklocation","Pik Location","trim|required");
			



			$this->form_validation->set_error_delimiters('<p class="text-danger">','</p>');

				if($this->form_validation->run() ){

				$ecid = $this->input->post('ecid');
 				$ecname = $this->input->post('ecname');
 				$ecnumber = $this->input->post('ecnumber');
 				$ecemail = $this->input->post('ecemail');
 				$ecaddress = $this->input->post('ecaddress');


 				$ebookid = $this->input->post('ebookid');
 				$eprice = $this->input->post('eprice');
 				$eadvprice = $this->input->post('eadvprice');
 				$epackage = $this->input->post('epackage');
 				$epredate = $this->input->post('epredate');
 				$eremark = $this->input->post('eremark');
 				$epiklocation = $this->input->post('epiklocation');
 				$ecarcolor = $this->input->post('ecarcolor');
 				$ecarnumber = $this->input->post('ecarnumber');
 				$ecarname = $this->input->post('ecarname');
 				$ecity = $this->input->post('ecity');


 				$bind = array( 'name' => $ecname,
 					 			'email' => $ecemail,
								'address' => $ecaddress,
								'number' => $ecnumber);
 				$table = 'customer';
 				$column = 'customer_id';


 					$bind_booking = array( 'vehicle' => $ecarnumber,
 					 			'vehicle_name' => $ecarname,
								'vehicle_color' => $ecarcolor,
								'remark_vehicle' => $eremark,
								'date' => $epredate,
								'pickup' => $epiklocation,
								'price' => $eprice,
								'advance' => $eadvprice,
								'package' => $epackage
							);
 				$table_booking = 'booking';
 				$column_booking = 'booking_id';

 				$insert_into_booking = $this->my_model->update_customer($table_booking,$column_booking,$bind_booking,$ebookid);
 				$insert_info = $this->my_model->update_customer($table,$column,$bind,$ecid);
 				$data = array('success' => true,'messages'=>'updated','insert_info'=>$insert_info.'--'.$insert_into_booking);
			}
			else
			{

				foreach ($_POST as $key => $value)
				{
					$data['messages'][$key] = form_error($key);
				}
			}
			echo json_encode($data);

	}

	public function add_booking()
	{



		$data = array('success' => false, 'message'=>array());
		$this->form_validation->set_rules("name","Name","trim|required");
		$this->form_validation->set_rules("mobile","Mobile","trim|required|numeric|max_length[10]");

		$this->form_validation->set_rules("cnf_mobile","Confirm Mobile","trim|required|matches[mobile]");

		$this->form_validation->set_rules("address1","Address","trim|required");

		$this->form_validation->set_rules("city","City","trim|required");

		$this->form_validation->set_rules("zip_code","Zip Code","trim|required|numeric|min_length[4]|max_length[6]");

		$this->form_validation->set_error_delimiters('<p class="text-danger">','</p>');

			





			if($this->form_validation->run() ){
				$cmd = $this->my_model->get_customer();
				$get_bk = $this->my_model->get_booking();

				$count = count($cmd);
				$count_bk = count($get_bk);	
				$member_id = 'DSMB00'.($count+1);
				$booking_id = 'DSBK00'.($count_bk+1);
				$name = $this->input->post('name');

 				$email = $this->input->post('email');

 				$state_id = $this->input->post('state_id');

 				$address1 = $this->input->post('address1');

 				$address2 = $this->input->post('address2');

 				$mobile = $this->input->post('mobile');

 				$city = $this->input->post('city');

 				$zip_code = $this->input->post('zip_code');





 				$bind = array('customer_id' => $member_id,

 					'name' => $name,

 					 'email' => $email,

 					 'state' => $state_id,'address' => $address1.$address2,'number' => $mobile,'city' => $city,'pincode' => $zip_code,'bookingid'=>'null');


 				$insert_info = $this->my_model->insert_customer($bind);



 		$data = array('success' => true,'messages'=>$member_id,'member_id'=>$member_id,'booking_id'=>$booking_id,'insert_info'=>$insert_info);



			}

			else

			{

				foreach ($_POST as $key => $value)

				{

					$data['messages'][$key] = form_error($key);

				}

			}

			echo json_encode($data);



	}



 



	public function add_booking_bind()

	{



			$data = array('success' => false, 'messages'=>array());

			

			//$this->form_validation->set_rules("membership_id","Member ID","trim|required");
			$this->form_validation->set_rules("car_name","Car Name","trim|required");


			$this->form_validation->set_rules("car_no","Car Number","trim|required");



			$this->form_validation->set_rules("date_time","Date Time","trim|required");

			$this->form_validation->set_rules("price","Total Price","trim|required");



			$this->form_validation->set_error_delimiters('<p class="text-danger">','</p>'); 



			if($this->form_validation->run() ){



				$mid = $this->input->post('membership_id');

 				$car_colour = $this->input->post('car_colour');

 				$car_detail = $this->input->post('car_detail');

 				$date_time = $this->input->post('date_time');

				$picup_location = $this->input->post('picup_location');

 				$description = $this->input->post('description');

 				$price = $this->input->post('price');

 				$advance_receive = $this->input->post('advance_receive');

 				$package = $this->input->post('package');

 				$car_name = $this->input->post('car_name');

 				$car_no = $this->input->post('car_no');

 				$date_time = $this->input->post('date_time');


 	          	$cmd = $this->my_model->get_customer_data($mid);	




		     	$count = count($cmd);



		     	$client_number = $cmd[0]->number;

		     	$client_email = $cmd[0]->email;

		   		if($count > 0) {

		   		$get_bk = $this->my_model->get_booking();

 

				$count_bk = count($get_bk);	

 				$booking_id = 'DSBK00'.($count_bk+1);

			//	$data = array('success' => true,'messages'=>$booking_id);

				

				$bind = array('booking_id' => $booking_id,
 					'vehicle' => $car_no,
 				'vehicle_name' => $car_name,
 				'vehicle_color' => $car_colour,
 				'remark_vehicle' => $car_detail,
 				'date' => $date_time,
 				'pickup' => $picup_location,
 				'remark_package' => $description,
 				'price' => $price,
 				'advance' => $advance_receive, 
 				'status' => '1',
 				'package' => $package,
 				'customer_id'=>$mid );
				 $cmd = $this->my_model->insert_booking($bind);

				 $data = array('success' => true, 'messages'=>$client_number );




						$curl = curl_init();

						curl_setopt_array($curl, array(
						  CURLOPT_URL => "http://api.msg91.com/api/sendhttp.php?sender=MSGIND&route=4&mobiles=$client_number&authkey=213786A8EZYX2C5aec1fbe&country=91&message=Thank for booking with Detailing-Street. Your Booking ID is $booking_id and appointment date is $date_time. Total amount $price Rs with token amount $advance_receive Rs.",
						  CURLOPT_RETURNTRANSFER => true,
						  CURLOPT_ENCODING => "",
						  CURLOPT_MAXREDIRS => 10,
						  CURLOPT_TIMEOUT => 30,
						  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
						  CURLOPT_CUSTOMREQUEST => "POST",
						  CURLOPT_POSTFIELDS => "",
						  CURLOPT_SSL_VERIFYHOST => 0,
						  CURLOPT_SSL_VERIFYPEER => 0,
						));

						$response = curl_exec($curl);
						$err = curl_error($curl);

						curl_close($curl);


					 /*mail send to client */


					  $config = array (
                  'mailtype' => 'html',
                  'charset'  => 'utf-8',
                  'priority' => '1'
                   );
        $this->email->initialize($config);


					 $from_email = "jayant.sws@gmail.com"; 
			       //  $to_email = $this->input->post('email'); 
			   
			         //Load email library 
			       

			         			        
			   
			         $this->email->from($from_email, 'Detailing Street'); 
			         $this->email->to($client_email);
			        // $this->email->subject('Detailing Street Booking Details'); 
			        // $this->email->message($body); 


			 
   
       
         $this->email->subject('Important !! Booking Details'); 
         $this->email->message('<!doctype html><html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office"> <head> <meta charset="UTF-8"> <meta http-equiv="X-UA-Compatible" content="IE=edge"> <meta name="viewport" content="width=device-width, initial-scale=1"> <title></title> <style type="text/css">p{margin:10px 0;padding:0;}table{border-collapse:collapse;}h1,h2,h3,h4,h5,h6{display:block;margin:0;padding:0;}img,a img{border:0;height:auto;outline:none;text-decoration:none;}body,#bodyTable,#bodyCell{height:100%;margin:0;padding:0;width:100%;}.mcnPreviewText{display:none !important;}#outlook a{padding:0;}img{-ms-interpolation-mode:bicubic;}table{mso-table-lspace:0pt;mso-table-rspace:0pt;}.ReadMsgBody{width:100%;}.ExternalClass{width:100%;}p,a,li,td,blockquote{mso-line-height-rule:exactly;}a[href^=tel],a[href^=sms]{color:inherit;cursor:default;text-decoration:none;}p,a,li,td,body,table,blockquote{-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%;}.ExternalClass,.ExternalClass p,.ExternalClass td,.ExternalClass div,.ExternalClass span,.ExternalClass font{line-height:100%;}a[x-apple-data-detectors]{color:inherit !important;text-decoration:none !important;font-size:inherit !important;font-family:inherit !important;font-weight:inherit !important;line-height:inherit !important;}a.mcnButton{display:block;}.mcnImage,.mcnRetinaImage{vertical-align:bottom;}.mcnTextContent{word-break:break-word;}.mcnTextContent img{height:auto !important;}.mcnDividerBlock{table-layout:fixed !important;}body,#bodyTable{background-color:#F2F2F2;}#bodyCell{border-top:0;}#ribbonContainer{background-color:#6DC6DD;}#templateContainer{border:0;}h1{color:#202020 !important;font-family:Helvetica;font-size:24px;font-style:normal;font-weight:bold;line-height:125%;letter-spacing:-1px;text-align:left;}h2{color:#202020 !important;font-family:Helvetica;font-size:22px;font-style:normal;font-weight:bold;line-height:125%;letter-spacing:-.75px;text-align:left;}h3{color:#202020 !important;font-family:Helvetica;font-size:18px;font-style:normal;font-weight:bold;line-height:125%;letter-spacing:-.5px;text-align:left;}h4{color:#202020 !important;font-family:Helvetica;font-size:16px;font-style:normal;font-weight:bold;line-height:125%;letter-spacing:normal;text-align:left;}#templatePreheader{background-color:#FFFFFF;border-top:0;border-bottom:1px solid #EEEEEE;}.preheaderContainer .mcnTextContent,.preheaderContainer .mcnTextContent p{color:#606060;font-family:Helvetica;font-size:11px;line-height:125%;text-align:left;}.preheaderContainer .mcnTextContent a{color:#606060;font-weight:normal;text-decoration:underline;}#templateHeader{background-color:#F2F2F2;border-top:0;border-bottom:0;}.headerContainer .mcnTextContent,.headerContainer .mcnTextContent p{color:#606060;font-family:Helvetica;font-size:15px;line-height:150%;text-align:left;}.headerContainer .mcnTextContent a{color:#6DC6DD;font-weight:normal;text-decoration:underline;}#templateBody{background-color:#F2F2F2;border-top:0;border-bottom:0;}.bodyContainer .mcnTextContent,.bodyContainer .mcnTextContent p{color:#606060;font-family:Helvetica;font-size:15px;line-height:150%;text-align:left;}.bodyContainer .mcnTextContent a{color:#6DC6DD;font-weight:normal;text-decoration:underline;}#templateFooter{background-color:#F2F2F2;border-top:1px solid #E5E5E5;border-bottom:0;}.footerContainer .mcnTextContent,.footerContainer .mcnTextContent p{color:#606060;font-family:Helvetica;font-size:11px;line-height:125%;text-align:left;}.footerContainer .mcnTextContent a{color:#606060;font-weight:normal;text-decoration:underline;}@media only screen and (max-width: 480px){body,table,td,p,a,li,blockquote{-webkit-text-size-adjust:none !important;}}@media only screen and (max-width: 480px){body{width:100% !important;min-width:100% !important;}}@media only screen and (max-width: 480px){.templateContainer{max-width:600px !important;width:100% !important;}}@media only screen and (max-width: 480px){.templateContainer,#templatePreheader,#templateHeader,#templateBody,#templateFooter{max-width:600px !important;width:100% !important;}}@media only screen and (max-width: 480px){.flexibleContainer{width:100% !important;}}@media only screen and (max-width: 480px){.mcnRetinaImage{max-width:100% !important;}}@media only screen and (max-width: 480px){.mcnImage{height:auto !important;width:100% !important;}}@media only screen and (max-width: 480px){.mcnCartContainer,.mcnCaptionTopContent,.mcnRecContentContainer,.mcnCaptionBottomContent,.mcnTextContentContainer,.mcnBoxedTextContentContainer,.mcnImageGroupContentContainer,.mcnCaptionLeftTextContentContainer,.mcnCaptionRightTextContentContainer,.mcnCaptionLeftImageContentContainer,.mcnCaptionRightImageContentContainer,.mcnImageCardLeftTextContentContainer,.mcnImageCardRightTextContentContainer,.mcnImageCardLeftImageContentContainer,.mcnImageCardRightImageContentContainer{max-width:100% !important;width:100% !important;}}@media only screen and (max-width: 480px){.mcnBoxedTextContentContainer{min-width:100% !important;}}@media only screen and (max-width: 480px){.mcnImageGroupContent{padding:9px !important;}}@media only screen and (max-width: 480px){.mcnCaptionLeftContentOuter .mcnTextContent,.mcnCaptionRightContentOuter .mcnTextContent{padding-top:9px !important;}}@media only screen and (max-width: 480px){.mcnImageCardTopImageContent,.mcnCaptionBottomContent:last-child .mcnCaptionBottomImageContent,.mcnCaptionBlockInner .mcnCaptionTopContent:last-child .mcnTextContent{padding-top:18px !important;}}@media only screen and (max-width: 480px){.mcnImageCardBottomImageContent{padding-bottom:9px !important;}}@media only screen and (max-width: 480px){.mcnImageGroupBlockInner{padding-top:0 !important;padding-bottom:0 !important;}}@media only screen and (max-width: 480px){.mcnImageGroupBlockOuter{padding-top:9px !important;padding-bottom:9px !important;}}@media only screen and (max-width: 480px){.mcnTextContent,.mcnBoxedTextContentColumn{padding-right:18px !important;padding-left:18px !important;}}@media only screen and (max-width: 480px){.mcnImageCardLeftImageContent,.mcnImageCardRightImageContent{padding-right:18px !important;padding-bottom:0 !important;padding-left:18px !important;}}@media only screen and (max-width: 480px){.mcpreview-image-uploader{display:none !important;width:100% !important;}}@media only screen and (max-width: 480px){h1{font-size:24px !important;line-height:125% !important;}}@media only screen and (max-width: 480px){h2{font-size:20px !important;line-height:125% !important;}}@media only screen and (max-width: 480px){h3{font-size:18px !important;line-height:125% !important;}}@media only screen and (max-width: 480px){h4{font-size:16px !important;line-height:125% !important;}}@media only screen and (max-width: 480px){.mcnBoxedTextContentContainer .mcnTextContent,.mcnBoxedTextContentContainer .mcnTextContent p{font-size:18px !important; line-height:125% !important;}}@media only screen and (max-width: 480px){#templatePreheader{display:block !important;}}@media only screen and (max-width: 480px){.preheaderContainer .mcnTextContent,.preheaderContainer .mcnTextContent p{font-size:14px !important;line-height:115% !important;}}@media only screen and (max-width: 480px){.headerContainer .mcnTextContent,.headerContainer .mcnTextContent p{font-size:18px !important;line-height:125% !important;}}@media only screen and (max-width: 480px){.bodyContainer .mcnTextContent,.bodyContainer .mcnTextContent p{font-size:18px !important;line-height:125% !important;}}@media only screen and (max-width: 480px){.footerContainer .mcnTextContent,.footerContainer .mcnTextContent p{font-size:14px !important;line-height:115% !important;}}</style></head> <body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0"> <span class="mcnPreviewText" style="display:none; font-size:0px; line-height:0px; max-height:0px; max-width:0px; opacity:0; overflow:hidden; visibility:hidden; mso-hide:all;"> DETAILING STREET SERVICES </span> <center> <table align="center" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%" id="bodyTable"> <tr> <td align="center" valign="top" id="bodyCell"> <table border="0" cellpadding="0" cellspacing="0" width="100%"> <tr> <td align="center" valign="top"> <table border="0" cellpadding="0" cellspacing="0" width="100%" id="templatePreheader"> <tr> <td align="center" valign="top"> <table border="0" cellpadding="0" cellspacing="0" width="640" class="flexibleContainer"> <tr> <td valign="top" class="preheaderContainer" style="padding-top:10px; padding-bottom:10px"><table border="0" cellpadding="0" cellspacing="0" width="100%" class="mcnTextBlock" style="min-width:100%;"> <tbody class="mcnTextBlockOuter"> <tr> <td valign="top" class="mcnTextBlockInner" style="padding-top:9px;"> <table align="left" border="0" cellpadding="0" cellspacing="0" style="max-width:100%; min-width:100%;" width="100%" class="mcnTextContentContainer"> <tbody><tr> <td valign="top" class="mcnTextContent" style="padding: 0px 18px 9px; text-align: center;"> <a href="*|ARCHIVE|*" target="_blank">View this email in your browser</a> </td></tr></tbody></table> </td></tr></tbody></table></td></tr></table> </td></tr></table> </td></tr><tr> <td align="center" valign="top"> <table border="0" cellpadding="0" cellspacing="0" width="640" class="templateContainer"> <tr> <td align="center" valign="top" width="60" id="ribbonContainer"> <table border="0" cellpadding="0" cellspacing="0"> <tr> <td align="center" valign="top" style="padding-top:18px; padding-right:4px; padding-bottom:18px; padding-left:4px;"> <img src="http://crm.detailingstreet.com/assets/img/logo-trans.png" height="40" width="40" class="mcnImage" style="border:0; display:block; line-height:100%; outline:none; text-decoration:none;"> </td></tr></table> </td><td align="center" valign="top" class="mobilePaddingR9" style="padding-bottom:9px; padding-left:9px;"> <table border="0" cellpadding="0" cellspacing="0" width="100%"> <tr> <td align="center" valign="top" style="padding-top:9px;"> <table border="0" cellpadding="0" cellspacing="0" width="100%" id="templateHeader"> <tr> <td valign="top" class="headerContainer"><table border="0" cellpadding="0" cellspacing="0" width="100%" class="mcnImageBlock" style="min-width:100%;"> <tbody class="mcnImageBlockOuter"> <tr> <td valign="top" style="padding:9px" class="mcnImageBlockInner"> <table align="left" width="100%" border="0" cellpadding="0" cellspacing="0" class="mcnImageContentContainer" style="min-width:100%;"> <tbody><tr> <td class="mcnImageContent" valign="top" style="padding-right: 9px; padding-left: 9px; padding-top: 0; padding-bottom: 0; text-align:center;"> <a href="http://crm.detailingstreet.com/assets/img/logo-trans.png" title="" class="" target="_blank"> <img align="center" alt="" src="http://crm.detailingstreet.com/assets/img/logo-trans.png" width="233" style="max-width:233px; padding-bottom: 0; display: inline !important; vertical-align: bottom;" class="mcnImage"> </a> </td></tr></tbody></table> </td></tr></tbody></table></td></tr></table> </td></tr><tr> <td align="center" valign="top"> <table border="0" cellpadding="0" cellspacing="0" width="100%" id="templateBody"> <tr> <td valign="top" class="bodyContainer"><table border="0" cellpadding="0" cellspacing="0" width="100%" class="mcnTextBlock" style="min-width:100%;"> <tbody class="mcnTextBlockOuter"> <tr> <td valign="top" class="mcnTextBlockInner" style="padding-top:9px;"> <table align="left" border="0" cellpadding="0" cellspacing="0" style="max-width:100%; min-width:100%;" width="100%" class="mcnTextContentContainer"> <tbody><tr> <td valign="top" class="mcnTextContent" style="padding-top:0; padding-right:18px; padding-bottom:9px; padding-left:18px;"> <strong>Dear  Customers</strong>,<br><br>&nbsp;&nbsp;<table border="0" cellpadding="0" cellspacing="0" width="95%"><tbody><tr><td align="left" valign="middle">Congratulations! Your&nbsp;car&nbsp;is&nbsp;booked&nbsp;with the following details:</td></tr><tr><td align="left" valign="middle"><br>Booking&nbsp;ID :&nbsp; '.$booking_id.'<br>Membership ID :&nbsp;'.$mid.'<br>Car&nbsp;/ Bike No. :&nbsp;'.$car_name.'<br><br>Workshop : Detailing Street, Mansarover Garden<br>Preferred Date : '.$date_time.'<br>Price :&nbsp;'.$price.'<br>Advance Received :&nbsp;'.$advance_receive.'</td></tr><tr></tr></tbody></table><br>Thanks for a great year.<br><br><br>Thank you!<br><br>Team Detailing Street​<br>&nbsp; </td></tr></tbody></table> </td></tr></tbody></table></td></tr></table> </td></tr><tr> <td align="center" valign="top"> <table border="0" cellpadding="0" cellspacing="0" width="100%" id="templateFooter"> <tr> <td valign="top" class="footerContainer" style="padding-bottom:9px;"></td></tr></table> </td></tr></table> </td></tr></table> </td></tr></table> </td></tr></table> </center> </body></html>'); 
   
         //Send mail 
         if($this->email->send()) 
         {
         $this->session->set_flashdata("email_sent","Email sent successfully."); 
         }
         else {
         $this->session->set_flashdata("email_sent","Error in sending Email."); 
        /* $this->load->view('email_form'); */
}
		   		}

		   		else

		   		{

		   			 $data = array('success' => false, 'messages'=>'0' );

		   		}

				 



				

			}

			else

			{

				foreach ($_POST as $key => $value)

				{



					$data['messages'][$key] = form_error($key);

					

				}



			}



			echo json_encode($data);





	}



}



?>