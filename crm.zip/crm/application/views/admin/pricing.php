
<?php include('header.php'); ?>

<?php include('menu.php'); ?>





<div class="content-wrapper" style="min-height: 673px;">

    <!-- Content Header (Page header) -->

    <section class="content-header">

      <h1>Pricing Detail</h1>

      <ol class="breadcrumb">

        <li><a href="https://crm.onyxaa.com/dashboard">Pricing</a></li>

        <li class="active">Pricing Detail</li>

      </ol>       

    </section>

<!-- Main content -->

  <section class="content">

    <div class="row">

      <div class="col-xs-12 col-md-12">

        <div class="box box-primary">

                     <div class="box-body">

           <div class="col-xs-12 col-md-8">

      <table id="list1" class="table table-bordered table-striped dataTable" role="grid" aria-describedby="list1_info">
        <thead>
          <tr>
          <th>Car Type</th>
          <th>Silver(1 year)</th>
          <th>Gold(3 year)</th>
          <th>Platinum(5 year)</th>
          </tr>
        </thead>
            <tbody>

                  <tr>
                    <td><strong>Hatchback</strong></td>
                      <td>Rs.10,000</td>
                      <td>Rs.15,000</td>
                      <td>Rs.20,000</td>
                    </tr>

                      <tr>
                    <td><strong>Sedan</strong></td>
                      <td>Rs.15,000</td>
                      <td>Rs.20,000</td>
                      <td>Rs.25,000</td>
                    </tr>
                      <tr>
                    <td><strong>Mini Suv</strong></td>
                      <td>Rs.18,000</td>
                      <td>Rs.23,000</td>
                      <td>Rs.28,000</td>
                    </tr>

                     <tr>
                    <td><strong>Suv</strong></td>
                      <td>Rs.22,000</td>
                      
                      <td>Rs.30,000</td>
                      <td>Rs.38,000</td>
                    </tr>

                     <td><strong>Luxury</strong></td>
                     <td>Rs.22,000</td>
                      
                      <td>Rs.30,000</td>
                      <td>Rs.38,000</td>
                    </tr>

                    <td><strong>Luxury Suv</strong></td>
                      <td>Rs.24,000</td>
                      
                      <td>Rs.32,000</td>
                      <td>Rs.40,000</td>
                    </tr>
                    
                    <td><strong>Interior (5-Seater)</strong></td>
                      <td>Rs.6,000</td>
                    
                    </tr>

                    <td><strong>Interior (7-Seater)</strong></td>
                      <td>Rs.8,000</td>
                    
                    </tr>

          </tbody>
        </table>

      </div>

          </div>

       </div>

        <!-- /.box --> 

      </div>

      <!-- /.col --> 

    </div>

    <!-- /.row --> 

  </section>

  <!-- /.content --> 

</div>



 

<?php include('footer.php'); ?>