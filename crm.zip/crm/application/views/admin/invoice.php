<?php 
 
include('header.php'); ?>

<?php include('menu.php'); ?>

<style type="text/css">
  

  .table-striped tr td {
        border: solid 1px black;
  }

    .table-striped tr th {
        border: solid 1px black;

    background-color: #c52d2dcc;
    color: #fff;
  }
</style>

<div class="content-wrapper" style="min-height: 542px;">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>

         Generate New Invoice 
      </h1>
 

   </section>

   <!-- Main content -->

   <section class="content">

      <div class="row">

         <div class="col-xs-12">

            <div class="box box-primary">

               <!-- /.box-header -->

               <div class="box-body">

                                

                  <form name="existing" class="form-horizontal" id="existing" enctype="multipart/form-data" method="post" accept-charset="utf-8" novalidate="novalidate" style="">

                 <div id="existing_div">

                <div class="form-group">
                  <label for="txt_bookingid" class="col-sm-2 control-label">Booking ID</label>

                  <div class="col-sm-6">
                    <input type="text" class="form-control" name="txt_bookingid" id="txt_bookingid" placeholder="Booking ID Like : DSBK0000">
                  </div>
                  <button class="btn btn-primary btn-next" type="button" id="btn_searchbooking" style="margin-left:10px;">Next </button> 
                </div>  
                </div>

                   </form>

                   <hr>
                   <section class="invoice">
      <!-- title row -->
      <div class="row">
        <div class="col-xs-12">
          <h2 class="page-header">
           <img src="http://crm.detailingstreet.com/assets/img/logo-trans.png" style="width: 200px;">
            <small class="pull-right" style="text-align: right;line-height: 18px;"><strong>Detailing Street Pvt. Ltd.</strong> <br>
              Plot #2, Parwana Road <br>
              Pitam Pura, Delhi  <br>
               INDIA -110034 <br>
             
            </small>
            
          </h2>
        </div>
        <!-- /.col -->
      </div>
      <!-- info row -->
      <div class="row invoice-info">
        <div class="col-sm-4 invoice-col">
          To
          <address>
            <strong>Admin, Inc.</strong><br>
            795 Folsom Ave, Suite 600<br>
            San Francisco, CA 94107<br>
            Phone: (804) 123-5432<br>
            Email: info@almasaeedstudio.com
          </address>
        </div>
        <!-- /.col -->
        <div class="col-sm-4 invoice-col">
           
        </div>
        <!-- /.col -->
        <div class="col-sm-4 invoice-col" >
          <b>Invoice #007612</b><br>
          <br>
          <b>CUSTOMER ID:</b> 4F3S8J<br>
          <b>BOOKING ID:</b> 4F3S8J<br>
          <b>Payment Date:</b> 2/22/2014<br>
          
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <div class="row">
        <div class="col-xs-12 table-responsive">
          <table class="table table-striped">
            <thead>
            <tr>
             <th>Payment Date</th>
              <th>Vehicle Type</th>
              <th>Car/Bike Type</th>
              <th>Registration No.</th>
             
              
            </tr>
            </thead>
            <tbody>
            <tr>
              <td>10-5-2018</td>
              <td>Car</td>
              <td>Luxury</td>
              <td>CH0012121</td>
              
             
            </tr>
            </tbody>
          </table>

           <table class="table table-striped">
            <thead>
            <tr>
               <th>Vehicle Model</th>
              <th>Payment Mode</th>
              <th>Vehicle Color</th>
              <th>Coating Studio</th>
             <!--  <th>Valid </th>
               <th>Payment Mode</th> -->
            </tr>
            </thead>
            <tbody>
            <tr>
              <td>BMW 320D</td>
               <td>Payment Mode</td>
              <td>BLUE</td>
              <td>Delhi</td>
              <!-- <td>BMW 320D</td>
              <td>Payment Mode</td> -->
            </tr>
            </tbody>
          </table>
        </div>
        <!-- /.col -->
      </div>
      <!-- Table row -->
      <div class="row">
        <div class="col-xs-12 table-responsive">
          <table class="table table-striped">
            <thead>
            <tr>
              <th>#</th>
              <th>Item & Description</th>
              <th>Qty</th>
              <th>Rate</th>
              <th>Tax %</th>
              <th>Tax </th>
              <th>Amount</th>
            </tr>
            </thead>
            <tbody>
            <tr>
              <td>1</td>
              <td>Call of Duty</td>
             
              <td>El snort testosterone trophy driving gloves handsome</td>
              <td>$64.50</td>
               <td>455-981-221</td>
                <td>455-981-221</td>
                 <td>455-981-221</td>
            </tr>
             <tr>
              <td>1</td>
              <td>Call of Duty</td>
             
              <td>El snort testosterone trophy driving gloves handsome</td>
              <td>$64.50</td>
               <td>455-981-221</td>
                <td>455-981-221</td>
                 <td>455-981-221</td>
            </tr>
              <tr>
              <td>1</td>
              <td>Call of Duty</td>
             
              <td>El snort testosterone trophy driving gloves handsome</td>
              <td>$64.50</td>
               <td>455-981-221</td>
                <td>455-981-221</td>
                 <td>455-981-221</td>
            </tr>
              <tr>
              <td>1</td>
              <td>Call of Duty</td>
             
              <td>El snort testosterone trophy driving gloves handsome</td>
              <td>$64.50</td>
               <td>455-981-221</td>
                <td>455-981-221</td>
                 <td>455-981-221</td>
            </tr>
            </tbody>
          </table>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <div class="row">
        <!-- accepted payments column -->
        <div class="col-xs-6">
          <p class="lead">Notice : </p>
          

          <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">
           All rates are inclusive of taxes.
T&C Apply**
<br>
           Enjoy the air of a brand new vehicle!!
In case of any query, please contact @ 011-45917500
Thank You for visiting our coating studio.
          </p>


        </div>
        <!-- /.col -->
        <div class="col-xs-6">
          <p class="lead">Total Amount</p>

          <div class="table-responsive">
            <table class="table">
              <tbody><tr>
                <th style="width:50%">Subtotal:</th>
                <td>$250.30</td>
              </tr>
              <tr>
                <th>Tax (9.3%)</th>
                <td>$10.34</td>
              </tr>
              <tr>
                <th>Shipping:</th>
                <td>$5.80</td>
              </tr>
              <tr>
                <th>Total:</th>
                <td>$265.24</td>
              </tr>
            </tbody></table>
          </div>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- this row will not appear when printing -->
      <div class="row no-print">
        <div class="col-xs-12">
          <a href="invoice-print.html" target="_blank" class="btn btn-default"><i class="fa fa-print"></i> Print</a>
         
          <button type="button" class="btn btn-primary pull-right" style="margin-right: 5px;">
            <i class="fa fa-download"></i> Generate PDF
          </button>
        </div>
      </div>
    </section>

               </div>

               <!-- /.box-body -->

            </div>

            <!-- /.box -->

         </div>

         <!-- /.col -->

      </div>

      <!-- /.row -->  

   </section>



   <!-- /.content -->

</div>





<script type="text/javascript">
   $(document).ready(function() {
    $('#list1').DataTable();
});


   $(document).on('click','#btn_searchbooking',function(){

    

       bid = $('#txt_bookingid').val();

       $.ajax({

        type:'post',
        url:'<?php echo base_url(); ?>/user/get_booking_byid',
        data:{"bid":bid},
        dataType:'json',
        success:function(htm){
              alert(htm);
        }

       });

   });
</script>
<?php include('footer.php'); ?>